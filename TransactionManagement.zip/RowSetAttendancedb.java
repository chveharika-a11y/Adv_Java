package attendancedb;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Statement;
import javax.sql.rowset.CachedRowSet;
import javax.sql.rowset.RowSetProvider;
public class RowSetAttendancedb {
	Connection con;
	Statement stmt;
	public void createConnection() {
		try {
			Class.forName("com.mysql.cj.jdbc.Driver");

			con=DriverManager.getConnection("jdbc:mysql://localhost:3306/attendancedb","root","svecw@123");
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (SQLException e) {
			// TODO Auto-generated catch block

			e.printStackTrace();

		}

	}

	public void doDBOperations() {
		try {
			con.setAutoCommit(false);
			CachedRowSet crs=RowSetProvider.newFactory().createCachedRowSet();
			crs.setUrl("jdbc:mysql://localhost:3306/attendancedb");
			crs.setUsername("root");
			crs.setPassword("svecw@123");
			crs.setCommand("select *from attendance");
			crs.execute();
			while(crs.next()) {
				System.out.println("regdno:"+crs.getInt(1));
				System.out.println("subject:"+crs.getString(2));
				System.out.println("data:"+crs.getString(3));
				System.out.println("status:"+crs.getString(4));

			}

			crs.absolute(4);
			System.out.println("4th row");
			System.out.println("regdno:"+crs.getInt(1));
			System.out.println("subject:"+crs.getString(2));
			System.out.println("data:"+crs.getString(3));
			System.out.println("status:"+crs.getString(4));
			crs.updateString("subject","JAVA");
			crs.updateRow();
			crs.moveToInsertRow();
			crs.updateInt(1,10001);
			crs.updateString(2,"JAVA");
			crs.updateInt(3,5);
			crs.updateInt(4,10000);
			crs.insertRow();
			crs.moveToCurrentRow();
			crs.acceptChanges(con);
			crs.close();
		} catch (SQLException e) {
			// TODO Auto-generated catch block

			e.printStackTrace();
		}
	}
}