package attendancedb;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;


public class PreparedStatementattendancedb {
	Connection con;
	PreparedStatement psmt;
	public void createConnection() {
			try {
				Class.forName("com.mysql.cj.jdbc.Driver");
				con=DriverManager.getConnection("jdbc:mysql://localhost:3306/attendancedb","root","svecw@123");
			} catch (ClassNotFoundException | SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
	}
	public void getStudentAttendance(int regdno) {
        String query = "SELECT * FROM attendance WHERE regdno = ?";
		try {
			 PreparedStatement psmt = con.prepareStatement(query);
			 psmt.setInt(1, regdno);
			 ResultSet rs =  psmt.executeQuery();
			while(rs.next()) {
	                System.out.println("Regd No : " + rs.getInt("regdno"));
//	                System.out.println("Subject : " + rs.getString("subject"));
//	                System.out.println("Data    : " + rs.getData("data"));
//	                System.out.println("Status  : " + rs.getString("status"));
			}
	        } catch (SQLException e) {
	            e.printStackTrace();
	        }
 }
	public void insertAttendance(int regdno,String subject,String data,String status) {
		try {
			String query="insert into attendance values(?,?,?,?)";
			PreparedStatement psmt=con.prepareStatement(query);
			psmt.setInt(1, regdno);
			psmt.setString(2, subject);
			psmt.setString(3, data);
			psmt.setString(4, status);
			int rows=psmt.executeUpdate();
			System.out.println("Row Inserted:"+rows);
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}
	public void UpdateAttendance(int regdno,String subject,String data,String status) {
		try {
			String query = "UPDATE attendance SET subject=?, data=?, status=? WHERE regdno=?";
			PreparedStatement psmt = con.prepareStatement(query);
			psmt.setString(1, subject);
			psmt.setString(2, data);
			psmt.setString(3, status);
			psmt.setInt(4, regdno);
			int rows=psmt.executeUpdate();
			System.out.println("Row Updated:"+rows);
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	public void deleteAttendance(int regdno) {
		try {
			String query="delete from attendance where regdno=?";
			PreparedStatement psmt=con.prepareStatement(query);
			psmt.setInt(1, regdno);
			int rows=psmt.executeUpdate();
			System.out.println("Rows Deleted:"+rows);
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		

	}
}



