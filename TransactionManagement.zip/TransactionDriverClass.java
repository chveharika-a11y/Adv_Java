package attendancedb;

public class TransactionDriverClass {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		TransactionManagement tc= new TransactionManagement();
		tc.createConnection();
        tc.insertAttendance();
	}
}
