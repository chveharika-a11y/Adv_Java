package attendancedb;

public class ScrollableClassDriver {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		ScrollableClass obj = new ScrollableClass();
        obj.createConnection();
        obj.scrollableUpdatableRSC();
	}

}
