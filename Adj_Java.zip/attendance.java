package attendancedb;

public class attendance {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
