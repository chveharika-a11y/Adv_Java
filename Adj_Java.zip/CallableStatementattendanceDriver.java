package attendancedb;

public class CallableStatementattendanceDriver {
	public static void main(String[] args) {
		// TODO Auto-generated method stub

    	CallableStatementattendancedb cd = new CallableStatementattendancedb();
    	cd.createConnection();
    	cd.createCallableProcedure(1218);
    	cd.createCallableFunction(1240);
	}

}
