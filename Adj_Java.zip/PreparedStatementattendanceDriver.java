package attendancedb;

public class PreparedStatementattendanceDriver {

	public static void main(String[] args) {
		PreparedStatementattendancedb psmtdemo=new PreparedStatementattendancedb();
		psmtdemo.createConnection();
		psmtdemo.getStudentAttendance(1215);
		psmtdemo.UpdateAttendance(1215, "python", "notes", "active");
		psmtdemo.deleteAttendance(1215);
		psmtdemo.insertAttendance(1218,"java","queries","pending");
		// TODO Auto-generated method stub

	}

}
