package attendancedb;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;

public class TransactionManagement {
    Connection con;
    PreparedStatement psmt;
    public void createConnection() {
        try {
            Class.forName("com.mysql.cj.jdbc.Driver");

            con = DriverManager.getConnection(
                    "jdbc:mysql://localhost:3306/attendancedb",
                    "root",
                    "svecw@123");

            System.out.println("Connection Created");
        } catch (ClassNotFoundException | SQLException e) {
            e.printStackTrace();
        }
    }
    
    public void insertAttendance() {
        String query = "INSERT INTO Attendance(regdno, subject, data, status) VALUES(?,?,?,?)";
        try {
            con.setAutoCommit(false);
            PreparedStatement psmt = con.prepareStatement(query);
            psmt.setInt(1, 100);
            psmt.setString(2, "Java");
            psmt.setString(3, "2026-08-06");
            psmt.setString(4, "Present");
            psmt.executeUpdate();
            psmt.setInt(1, 108);
            psmt.setString(2, "DBMS");
            psmt.setString(3, "2026-08-06");
            psmt.setString(4, "Absent");
            psmt.executeUpdate();
            con.commit();
            System.out.println("Transaction Committed Successfully");
        } catch (Exception e) {
            try {
                con.rollback();
                System.out.println("Transaction Rolled Back");
            } catch (SQLException ex) {
                ex.printStackTrace();
            }

            e.printStackTrace();
        }
    }
}