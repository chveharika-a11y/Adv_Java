package attendancedb;

public class RowSetDriverClass {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		RowSetAttendancedb rs=new RowSetAttendancedb();
		rs.createConnection();
		rs.doDBOperations();

	}

}
