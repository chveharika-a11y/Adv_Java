package servletpackage;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class CompanyProfileServlet
 */
@WebServlet("/CompanyProfileServlet")
public class CompanyProfileServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public CompanyProfileServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.setContentType("text/html");

        PrintWriter out = response.getWriter();

		out.println("<html>");
        out.println("<head>");
        out.println("<title>Company Profile</title>");
        out.println("</head>");

        out.println("<body>");

        out.println("<h1>Company Profile</h1>");

        out.println("<h2>Company Name</h2>");
        out.println("<p>Tech Solutions Pvt. Ltd.</p>");

        out.println("<h2>Industry</h2>");
        out.println("<p>Information Technology</p>");

        out.println("<h2>Headquarters</h2>");
        out.println("<p>Bangalore, India</p>");

        out.println("<h2>Services</h2>");
        out.println("<ul>");
        out.println("<li>Web Development</li>");
        out.println("<li>Software Development</li>");
        out.println("<li>Cloud Computing</li>");
        out.println("<li>IT Consulting</li>");
        out.println("</ul>");

        out.println("<h2>Employee Strength</h2>");
        out.println("<p>500+</p>");

        out.println("<h2>Website</h2>");
        out.println("<p>www.techsolutions.com</p>");

        out.println("</body>");
        out.println("</html>");
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
