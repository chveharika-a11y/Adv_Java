package attendancedb;
import java.sql.*;
public class CallableStatementattendancedb {
    Connection con;
    CallableStatement cs;
    public void createConnection() {
            try {
				Class.forName("com.mysql.cj.jdbc.Driver");
				con = DriverManager.getConnection(
				        "jdbc:mysql://localhost:3306/attendancedb","root","svecw@123");
			} catch (ClassNotFoundException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}

    }
    //Procedure
    public void createCallableProcedure(int regdno) {
            try {
				cs = con.prepareCall("{call get_attendance_details(?,?)}");
				cs.setInt(1, regdno);
				cs.registerOutParameter(2, Types.VARCHAR);
				cs.execute();
				System.out.println("Student status : " + cs.getString(2));
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
    }


    // Function

    public void createCallableFunction(int regdno) {
            try {
				cs = con.prepareCall("{? = call get_status_from_attendance(?)}");
				cs.registerOutParameter(1, Types.VARCHAR);
				cs.setInt(2, regdno);
				cs.execute();
				System.out.println("Student status : " + cs.getString(1));
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}

    }
}