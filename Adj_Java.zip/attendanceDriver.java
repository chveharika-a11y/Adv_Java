package attendancedb;

public class attendanceDriver {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
