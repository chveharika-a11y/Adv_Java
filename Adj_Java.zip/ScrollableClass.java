package attendancedb;
import java.sql.*;

public class ScrollableClass {
	 Connection con;
	 Statement stmt;
	 public void createConnection() {
		 try {
			Class.forName("com.mysql.cj.jdbc.Driver");
			con=DriverManager.getConnection("jdbc:mysql://localhost:3306/attendancedb","root","svecw@123");
		} catch (ClassNotFoundException | SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	 }
	 public void scrollableUpdatableRSC() {
	        String query = "select * from Attendance";
	            try {
					stmt = con.createStatement(ResultSet.TYPE_SCROLL_SENSITIVE,ResultSet.CONCUR_UPDATABLE);
					ResultSet rs = stmt.executeQuery(query);
					rs.afterLast();
					while (rs.previous()) {
					    if (rs.getString(1).equals("1217")) {
					        rs.updateString("status", "ACTIVE");
					        rs.updateRow();
					    }
					    System.out.println("regdno : " + rs.getInt(1));
					    System.out.println("subject: " + rs.getString(2));
					    System.out.println("data : " + rs.getString(3));
					    System.out.println("status : " + rs.getString(4));
					    System.out.println();
					}
					rs.absolute(3);
					System.out.println("Absolute Record");
					System.out.println("regdno : " + rs.getInt(1));
					System.out.println("subject : " + rs.getString(2));
					System.out.println("data : " + rs.getString(3));
					System.out.println("status : " + rs.getString(4));
					rs.relative(1);
					System.out.println();
					System.out.println("regdno : " + rs.getInt(1));
					System.out.println("subject  :" + rs.getString(2));
					System.out.println("data : " + rs.getString(3));
					System.out.println("status : " + rs.getString(4));
					rs.moveToInsertRow();
					rs.updateInt(1, 12);
					rs.updateString(2, "adjjava");
					rs.updateString(3, "notebook");
					rs.updateString(4, "pending");
					rs.insertRow();
					rs.first();
					rs.deleteRow();
					System.out.println("First Record Deleted");
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();

				}   

	    }

	}
	 
