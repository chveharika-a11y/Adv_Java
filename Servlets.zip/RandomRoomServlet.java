package servletpackage;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class RandomRoomServlet
 */
@WebServlet("/RandomRoomServlet")
public class RandomRoomServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public RandomRoomServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		
		response.setContentType("text/html");

        PrintWriter out = response.getWriter();

        int room = (int)(Math.random() * 20) + 101;

        out.println("<html>");
        out.println("<head>");
        out.println("<title>Random Room</title>");

        // Refresh page every 5 seconds
        out.println("<meta http-equiv='refresh' content='5'>");

        out.println("</head>");

        out.println("<body>");

        out.println("<h1>Random Room Number</h1>");

        out.println("<h2>Room Number: " + room + "</h2>");

        out.println("<p>The room number will refresh every 5 seconds.</p>");

        out.println("</body>");
        out.println("</html>");
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
