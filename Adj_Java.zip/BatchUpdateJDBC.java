package attendancedb;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

public class BatchUpdateJDBC {
	Connection con;
	PreparedStatement psmt;
	public void createConnection() {
		try {
			Class.forName("com.mysql.cj.jdbc.Driver");
			con=DriverManager.getConnection("jdbc:mysql://localhost:3306/attendancedb","root","svecw@123");
		} catch (ClassNotFoundException | SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	public void BatchInsert() {
				try {
					String query="insert into Attendance value(?,?,?,?)";
					psmt = con.prepareStatement(query);
					ArrayList<String> Students=new ArrayList<String>();
					Students.add("1201,python,notes1,pending");
					Students.add("1202,dbms,queries,active");
					Students.add("1203,fsd,notes2,pending");
					Students.add("1204,fsd,notes2,ACTIVE");
					for(String Student:Students) {
						String columns[]=Student.split(",");
						psmt.setInt(1, Integer.parseInt(columns[0]));
//						psmt.setString(1, columns[0]);
						psmt.setString(2, columns[1]);
						psmt.setString(3,columns[2]);
						psmt.setString(4, columns[3]);
						psmt.addBatch();
					}
					int rows[]=psmt.executeBatch();
					System.out.println(rows.length+"no.of updates done in DB");
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
	}
	public void selectAttendance(int regdno){

		String query=("Select * from Attendance");
		try {
			psmt=con.prepareStatement(query);
			
			ResultSet rs=psmt.executeQuery();
			while(rs.next()) {
				System.out.println("regdno:"+rs.getInt(1));
				System.out.println("subject:"+rs.getString(2));
				System.out.println("data:"+rs.getString(3));
				System.out.println("status:"+rs.getString(4));
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
}
				
	
				

				
