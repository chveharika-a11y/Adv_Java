package servletpackage;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class ProductLifecycleServlet
 */
@WebServlet("/ProductLifecycleServlet")
public class ProductLifecycleServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public ProductLifecycleServlet() {
        super();
        System.out.println("Constructor executed");
    }
        public void init() throws ServletException {
            System.out.println("init() executed");
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
        protected void service(HttpServletRequest request, HttpServletResponse response)
                throws ServletException, IOException {

            System.out.println("service() executed");
		// TODO Auto-generated method stub
		
		 response.setContentType("text/html");

	        PrintWriter out = response.getWriter();

	        out.println("<html>");
	        out.println("<body>");
	        out.println("<h1>Product Lifecycle Servlet</h1>");
	        out.println("<h2>service() method executed</h2>");
	        out.println("</body>");
	        out.println("</html>");
	    }

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
        public void destroy() {
            System.out.println("destroy() executed");
	}

}
