package attendancedb;

public class BatchUpdateJDBCDriver {

	public static void main(String[] args) {
		BatchUpdateJDBC obj=new BatchUpdateJDBC();
		obj.createConnection();
		obj.BatchInsert();
		obj.selectAttendance(1217);
		// TODO Auto-generated method stub

	}

}
